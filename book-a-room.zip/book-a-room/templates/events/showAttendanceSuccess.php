<link href="<?php echo plugins_url(); ?>/book-a-room/css/bookaroom_meetings.css" rel="stylesheet" type="text/css"/>
<div class=wrap>
	<div id="icon-options-general" class="icon32"></div>
	<h2>
		<?php _e( 'Book a Room Administration - Attendance', 'book-a-room' ); ?>
	</h2>
</div>
<h2>
	<?php _e( 'Edit Attendance', 'book-a-room' ); ?>
</h2>
<p><?php _e( 'You have successfully entered attendance numbers for this event.', 'book-a-room' ); ?></p>
<p><a href="?page=bookaroom_event_management_upcoming"><?php _e( 'Go back to search.', 'book-a-room' ); ?></a></p>