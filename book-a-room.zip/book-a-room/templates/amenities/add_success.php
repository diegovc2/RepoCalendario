<link href="<?php echo plugins_url(); ?>/book-a-room/css/bookaroom_meetings.css" rel="stylesheet" type="text/css"/>
<div class=wrap>
	<div id="icon-options-general" class="icon32"></div>
	<h2>
		<?php _e( 'Book a Room Administration - Amenities', 'book-a-room' ); ?>
	</h2>
</div>
<h2>
	<?php _e( 'Add Amenity', 'book-a-room' ); ?>
</h2>
<p><?php _e( 'You have successfully added this amenity.', 'book-a-room' ); ?></p>
<p><a href="?page=bookaroom_Settings_Amenities"><?php _e( 'View amenity list.', 'book-a-room' ); ?></a></p>

