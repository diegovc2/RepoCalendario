<h2><?php _e( 'Book a Room Email Test', 'book-a-room' ); ?></h2>
<p><?php _e( 'This is a test from the Book a Room options. 1234', 'book-a-room' ); ?></p>
<p><?php _e( 'The email went to the following address(es):', 'book-a-room' ); ?> #bookaroom_alertEmail#</p>