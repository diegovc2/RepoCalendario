<link href="<?php echo plugins_url(); ?>/book-a-room/css/bookaroom_meetings.css" rel="stylesheet" type="text/css"/>
<div class=wrap>
	<div id="icon-options-general" class="icon32"></div>
	<h2>
		<?php _e( 'Book a Room - Meeting Reservations', 'book-a-room' ); ?>
	</h2>
</div>
<h2>
	<?php _e( 'Edit Pending Reservations', 'book-a-room' ); ?>
</h2>
<p><?php _e( 'The ID you are trying to view is missing or doesn\'t exist. It may have been deleted or there is an error with the system. Please try again. If the problem persists, please notify the webmaster.', 'book-a-room' ); ?></p>